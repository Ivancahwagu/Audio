import fetch from "node-fetch";
import fs from "fs"
import { reSize } from "./lib/resize.js"
import { igdl3 } from "./scrape/igdlv3.js"
import { igdl } from "./scrape/igdl.js"
import { tesmime } from "./lib/checkmime.js"
import { ttdl } from "./scrape/ttdlv2.js"
import { ytshort } from "./scrape/ytshort.js"
import { ytdl } from "./scrape/ytdlv2.js"
import { logo } from "./scrape/logo.js"
import { ai } from "./scrape/ai.js"
import { yts } from "./scrape/yts.js";
import { searchnpm } from "./scrape/npmsearch.js"
import util from "util"
import { exec } from "child_process"
import { igstory } from "./scrape/igstory.js"
import { toAudio, toPTT, toVideo, ffmpeg } from "./lib/convert.js";

export default async function resom(van, store, m) {
   try {
      van.sendMedia = async (jid, link, cap, quo) => {
         try {
            let data = await tesmime(link);
            if (data.type === "video") {
               return await van.sendMessage(jid, { video: data.buffer, fileName: Date.now() + ".mp4", caption: cap }, quo);
            } else if (data.type === "image") {
               return await van.sendMessage(jid, { image: data.buffer, fileNamr: Date.now() + ".jpg", caption: cap }, quo);
            } else if (data.type === "audio") {
               let res = await toPTT(data.buffer, "mp3");
               await van.sendMessage(jid, { audio: res.data, mimetype: "audio/ogg; codecs=opus" }, quo);
               return fs.unlinkSync("./" + res.filename);
            }
         } catch (error) {
            console.error('Error sendMedia:', error);
         }
      }

      van.sendAudio = async (jid, aud, quo) => {
         try {
            let res = await toPTT(aud, "mp3");
            await van.sendMessage(jid, { audio: res.data, mimetype: "audio/ogg; codecs=opus" }, quo);
            return fs.unlinkSync("./" + res.filename);
         } catch (error) {
            console.error('Error sendAudio:', error);
         }
      }
      global.user = "@" + m.sender.split("@")[0]
      let quoted = m.isQuoted ? m.quoted : m
      let isCommand = m.prefix && m.pesan.startsWith(m.prefix) || false
      global.quo = { quoted: m, ephemeralExpiration: m.expiration };

      let log = `
-S-A-N-S-B-O-T-L-I-T-E-       
dari: ${m.pushName} || ${m.sender}
chat: ${m.chat}
dari grup: ${m.isGroup ? "iya" : "tidak"}
command: ${m.command}
pesan: ${m.pesan || m.type}
bot: ${m.isBot? "ya" : "tidak"}
type: ${m.type}
-S-A-N-S-B-O-T-L-I-T-E-       
     `

      if (m.message && !m.isBot) {
         console.log(log)
         await van.sendPresenceUpdate('composing', m.chat)
         switch (isCommand ? m.command.toLowerCase() : false) {
            case "menu": case "info": case "m": {
               let text = {
                  main: [
                     "menu",
                     "help",
                     "donasi"
                  ],
                  download: [
                     "ig",
                     "iga",
                     "tt",
                     "tiktok",
                     "tta",
                     "tiktokaudio",
                     "ytshort",
                     "youtube",
                     "play"
                  ],
                  ai: [
                     "ai",
                     "logo"
                  ]
               }
               let img = fs.readFileSync("./img/menu2.jpg")
               van.sendMessage(m.chat, {
                  document: { url: "https://github.com" },
                  jpegThumbnail: await reSize(img, 300, 150),
                  fileName: "menu sansbot",
                  mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                  fileLength: "99999999999999",
                  pageCount: "999999",
                  caption: `hai ${user},
total fitur: ${text.main.length + text.download.length + text.ai.length}

berikut list menunya:
             
[ main ]

${text.main.map(i => m.prefix + i).join("\n")}

[ downloader ]

${text.download.map(i => m.prefix + i).join("\n")}

[ ai ]

${text.ai.map(i => m.prefix + i).join("\n")}

ini bot baru!
jadi bot ini masih masa pengembangan`, contextInfo: {
                     mentionedJid: [m.sender],
                     isForwarded: true,
                     forwardingScore: 999,
                     forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363144038483540@newsletter",
                        newsletterName: "SANSBOT BY IVAN",
                        contentType: 3,
                        accessibilityText: "SANSBOT BY IVAN"
                     },
                     externalAdReply: {
                        thumbnail: fs.readFileSync("./img/menu.jpg"),
                        title: "sansbot-lite",
                        body: "menu",
                        sourceUrl: "https://wa.me/6285809011357",
                        mediaType: 1,
                        renderLargerThumbnail: true
                     }
                  }
               }, { quoted: m, ephemeralExpiration: m.expiration })
            }
               break
            case "donasi": {
               van.sendMessage(m.chat, {
                  image: { url: "https://telegra.ph/file/5bd38afcc2d78f05dbfe3.jpg" },
                  fileName: "donasi.jpg",
                  caption: `hai kak ${user}, scan kode qr qris ini untuk mensupport bot ini`, contextInfo: {
                     mentionedJid: [m.sender]
                  }
               }, { quoted: m, ephemeralExpiration: m.expiration })
            }
               break
            case "owner": {
               const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
                  + 'VERSION:3.0\n'
                  + 'FN:ivan\n' // full name
                  + 'ORG:owner sansbot;\n' // the organization of the contact
                  + 'TEL;type=CELL;type=VOICE;waid=6285809011357:+62 858-0901-1357\n' // WhatsApp ID + phone number
                  + 'END:VCARD'
               van.sendMessage(
                  m.chat,
                  {
                     contacts: {
                        displayName: 'ivan',
                        contacts: [{ vcard }]
                     }
                  }, { quoted: m, ephemeralExpiration: m.expiration }
               )

            }
               break
            case "send": {
               if (!m.text) return m.reply("link?")
               van.sendMedia(m.chat, m.text, quo)
            }
               break
            case "ig": case "instagram": {
               try {
                  if (!m.text) return m.reply("link?")
                  let hasil = await igdl3(m.text)
                  if (hasil.length === 0) {
                     hasil = await igdl(m.text)
                     hasil = hasil.media
                  }
                  for (let i = 0; i < hasil.length; i++) {
                     van.sendMedia(m.chat, hasil[i], null, quo)
                  }
               } catch (e) {
                  m.reply("GAGAL DI UNDUH COBA DOWNLOAD ULANG")
               }
            }
               break
            case "iga": case "igaudio": case "instagramaudio": {
               try {
                  if (!m.text) return m.reply("mana linknya?")
                  let hasil = await igdl3(m.text)
                  hasil = await (await fetch(hasil[0])).buffer()
                  van.sendAudio(m.chat, hasil, null, quo)
               } catch (e) {
                  m.reply("GAGAL DI UNDUH COBA DOWNLOAD ULANG")
               }
            }
               break
            case "carinpm": case "npmsearch": {
               if (!m.text) return m.reply("query?")
               let hasil = await searchnpm(m.text);


               hasil = JSON.stringify(hasil, null, 2);
               van.sendMessage(m.chat, { text: hasil }, quo)
            }
               break
            case "ai": case "openai": {
               try {
                  if (!m.text) return m.reply("query?")
                  let hasil = await ai(m.sender, m.pushName, m.text)
                  await m.reply(hasil)
               } catch (e) {
                  m.reply("GAGAL DI RESPON SILAHKAN COBA LAGI:\n\n" + e)
               }
            }
               break
            case "tt": case "tiktok": case "ttdl": {
               try {
                  if (!m.text) return m.reply("link?")
                  let data = await ttdl(m.text)
                  van.sendMedia(m.chat, data.nowm, `nih kak\n\nhd: ${data.nowmhd}`, quo)
                  van.sendMedia(m.chat, data.audio, null, quo)
               } catch (e) {
                  m.reply("gagal di respon. coba kirim perintah ulang")
               }
            }
               break
            case "ttaudio": case "tta": case "tiktokaudio": {
               try {
                  if (!m.text) return m.reply("link?")
                  let hasil = await ttdl(m.text)
                  hasil = await (await fetch(hasil.nowm)).buffer()
                  van.sendAudio(m.chat, hasil, quo)
               } catch (e) {
                  m.reply("gagal di respon. coba kirim perintah ulang")
               }
            }
               break
            case "restart": {
               await m.reply('```R E S T A R T . . .```')
               process.send('reset')
            }
               break
            case "ytshort": {
               try {
                  if (!m.text) return m.reply("link yt shortnya mana?")
                  let res = await ytshort(m.text)
                  van.sendMedia(m.chat, res.videosd, `title: ${res.title}
thumnail: ${res.thumbnail}
hd: ${res.videohd}`, quo)
               } catch (e) {
                  m.reply("maaf kak, gagal di unduh. silahkan coba lagi")
               }
            }
               break
            case "yt": case "youtube": case "ytdl": {
               try {
                  if (!m.text) return m.reply("cara palai: .ytdl link|hd\npilihan: hdr, hd, sd, audio, cek")
                  let [link, type] = m.text.split("|")
                  if (!type) {
                     type = "audio"
                  }
                  let hasil = await ytdl(link, type)
                  if (type === "audio" || type === "mp3") {
                     hasil = await (await fetch(hasil.download)).buffer()
                     return van.sendAudio(m.chat, hasil, quo)
                  } else if (type === "cek") {
                     return m.reply(JSON.stringify(hasil, null, 2))
                  }
                  van.sendMedia(m.chat, hasil.download, `title: ${hasil.title}\nurl: ${hasil.url}\nthumbnail: ${hasil.thumb}`, quo)
               } catch (e) {
                  let cek = await ytdl(link, "cek")
                  m.reply("tersedia: " + JSON.stringify(cek, null, 2))
               }
            }
               break
            case "logo": case "logoai": {
               if (!m.text) return m.reply("contoh cara pemakaian: .logo ivan|shop")
               let [nama, type] = m.text.split("|")
               let hasil = await logo(nama, type)
               for (let i = 0; i < hasil.length; i++) {
                  van.sendMedia(m.chat, hasil[i], null, quo)
               }
            }
               break
            case "yts": case "youtubesearch": {
               if (!m.text) return m.reply("mau cari apa?")
               let hasil = await yts(m.text)
               hasil = hasil.map(a => `---------------
judul: ${a.label}
link: ${a.link}
thumbnail: ${a.thumb}
---------------
`).join('\n')
               m.reply(hasil)
            }
               break
            case "play": {
               try {
                  if (!m.text) return m.reply("cara palai: .play judul|hd\npilihan: hdr, hd, sd, audio, cek")
                  let [query, type] = m.text.split("|")
                  let res = await yts(query)
                  let link = res[0].link
                  if (!type) {
                     type = "audio"
                  }
                  let hasil = await ytdl(link, type)
                  if(!hasil.download) {
                     link = res[1].link
                     hasil = await ytdl(link, type)
                  }
                  if (type === "audio" || type === "mp3") {
                     hasil = await (await fetch(hasil.download)).buffer()
                     return van.sendAudio(m.chat, hasil, quo)
                  } else if (type === "cek") {
                     return m.reply(JSON.stringify(hasil, null, 2))
                  }
                  van.sendMedia(m.chat, hasil.download, `title: ${res.label}\nurl: ${link}\nthumbnail: ${res.thumb}`, quo)
               } catch (e) {
                  let cek = await ytdl(link, "cek")
                  m.reply("tersedia: " + JSON.stringify(cek, null, 2))
               }
            }
               break
            case "quoted": {
               van.sendMessage(m.chat, { text: JSON.stringify(m.quoted, null, 2) }, quo)
            }
               break
            case "igstory": {
               try {
                  if (!m.text) return m.reply("masukkan usernamenya!")
                  let hasil = await igstory(m.text)
                  console.log(hasil)
                  for (let i = 0; i < hasil.length; i++) {
                     van.sendMedia(m.chat, hasil[i], null, quo)
                  }
               } catch (e) {

               }
            }
            break
            default:
            // eval
            if ([">", "eval", "=>"].some(a => m.command.toLowerCase().startsWith(a))) {
               let evalCmd = ""
               try {
                  evalCmd = /await/i.test(m.text) ? eval("(async() => { " + m.text + " })()") : eval(m.text)
               } catch (e) {
                  evalCmd = e
               }
               new Promise(async (resolve, reject) => {
                  try {
                     resolve(evalCmd);
                  } catch (err) {
                     reject(err)
                  }
               })
                  ?.then((res) => m.reply(util.format(res)))
                  ?.catch((err) => m.reply(util.format(err)))
            }

            // exec
            if (["$", "exec"].some(a => m.command.toLowerCase().startsWith(a))) {
               try {
                  exec(m.text, async (err, stdout) => {
                     if (err) return m.reply(util.format(err))
                     if (stdout) return m.reply(util.format(stdout))
                  })
               } catch (e) {
                  await m.reply(util.format(e))
               }
            }
         }//end
      }
   } catch (e) {
      await m.reply(util.format(e))
   }
}