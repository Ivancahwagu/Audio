import "./setelan.js"
import makeWASocket, { downloadMediaMessage, generateForwardMessageContent, generateWAMessageFromContent, areJidsSameUser, extractMessageContent, delay, useMultiFileAuthState, fetchLatestWaWebVersion, makeInMemoryStore, jidNormalizedUser, PHONENUMBER_MCC, DisconnectReason } from "baileys"
import { Boom } from '@hapi/boom'
import pino from "pino"
import fs from "fs"
import { join } from 'path';
import http from 'http';
const logger = pino({ level: "silent" })
const usePairingCode = nomor
const store = makeInMemoryStore({ logger })

const runSans = async () => {
   const { state, saveCreds } = await useMultiFileAuthState(`./${sesi}`)
   const { version, isLatest } = await fetchLatestWaWebVersion()

   console.log(`using WA v${version.join('.')}, isLatest: ${isLatest}`)

   const van = makeWASocket.default({
      logger: logger,
      version,
      printQRInTerminal: !usePairingCode,
      browser: ['Chrome (Linux)', '', ''],
      generateHighQualityLinkPreview: true,
      auth: state,
      getMessage: async (key) => {
         if (store) {
             const msg = await store.loadMessage(key.remoteJid, key.id)
             return msg.message || undefined
         }
         return {
             conversation: "Hai Im sansBot"
         }
     }
   })

   store?.bind(van.ev);
   if (usePairingCode && !van.authState.creds.registered) {
      let phoneNumber = usePairingCode.replace(/[^0-9]/g, '')

      if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) throw "Start with your country's WhatsApp code, Example : 62xxx"

      await delay(3000)
      let code = await van.requestPairingCode(phoneNumber)
      console.log(`\x1b[32m${code?.match(/.{1,4}/g)?.join("-") || code}\x1b[39m`)
   }

   van.ev.on("connection.update", (update) => {
      const { lastDisconnect, connection, qr } = update
      if (connection) {
         console.info(`Connection Status : ${connection}`)
      }

      if (connection === "close") {
         let reason = new Boom(lastDisconnect?.error)?.output.statusCode

         switch (reason) {
            case DisconnectReason.badSession:
               console.info(`Bad Session File, Restart Required`)
               runSans()
               break
            case DisconnectReason.connectionClosed:
               console.info("Connection Closed, Restart Required")
               runSans()
               break
            case DisconnectReason.connectionLost:
               console.info("Connection Lost from Server, Reconnecting...")
               runSans()
               break
            case DisconnectReason.connectionReplaced:
               console.info("Connection Replaced, Restart Required")
               runSans()
               break
            case DisconnectReason.restartRequired:
               console.info("Restart Required, Restarting...")
               runSans()
               break
            case DisconnectReason.loggedOut:
               console.error("Device has Logged Out, please rescan again...")
               van.end()
               fs.rmSync(`./${sesi}`, { recursive: true, force: true })
               break
            case DisconnectReason.multideviceMismatch:
               console.error("Nedd Multi Device Version, please update and rescan again...")
               van.end()
               fs.rmSync(`./${sesi}`, { recursive: true, force: true })
               break
            default:
               console.log("Aku ra ngerti masalah opo iki")
               runSans()
         }
      }

      if (connection === "open") {
         console.log("berhasil login")
      }
   })


   van.ev.on("messages.upsert", async ({ messages }) => {
      for (let m of messages) {
          try {
              await (await import(`./lib/simple.js?v=${Date.now()}`)).default(m, store, van, parseMessage, getContentType, jidNormalizedUser, areJidsSameUser, downloadMediaMessage, generateForwardMessageContent, generateWAMessageFromContent, escapeRegExp)
              await (await import(`./respon.js?v=${Date.now()}`)).default(van, store, m)
          } catch (e) {
              console.log("terjadi kesalahan: " + e);
          }
      }
  });
  

   van.ev.on('creds.update', saveCreds)
}
async function getMessage(key){
   if (store) {
       const msg = await store.loadMessage(key.remoteJid, key.id)
       return msg?.message
   }
   return {
       conversation: "Hai Im juna Bot"
   }
}
function getContentType(content) {
   if (content) {
      const keys = Object.keys(content);
      const key = keys.find(k => (k === 'conversation' || k.endsWith('Message') || k.includes('V2') || k.includes('V3')) && k !== 'senderKeyDistributionMessage');
      return key
   }
}
function parseMessage(content) {
   content = extractMessageContent(content)

   if (content && content.viewOnceMessageV2Extension) {
      content = content.viewOnceMessageV2Extension.message
   }
   if (content && content.protocolMessage && content.protocolMessage.type == 14) {
      let type = getContentType(content.protocolMessage)
      content = content.protocolMessage[type]
   }
   if (content && content.message) {
      let type = getContentType(content.message)
      content = content.message[type]
   }

   return content
}
function escapeRegExp(string) {
   return string.replace(/[.*=+:\-?^${}()|[\]\\]|\s/g, '\\$&')
}

runSans()