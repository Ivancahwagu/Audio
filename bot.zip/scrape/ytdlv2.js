import axios from "axios";
import cheerio from "cheerio";

function ytdl(asu, type) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await axios.post("https://y"+"t1ss.pr"+"o/mat"+"es/en/an"+"alyze"+"/ajax", {
        url: asu,
        q_auto: 0,
        ajax: 1
      }, {
        headers: {
          "accept": "application/json, text/javascript, */*; q=0.01",
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "cookie": "sc_is_visitor_unique=rx12884893.1698636532.F644C5CB57ED4F178299746B4596E8F1.1.1.1.1.1.1.1.1.1",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
        }
      });

      if (response.status === 200) {
        const $ = cheerio.load(response.data.result);
        const thum = $("div.col-xs-12.col-12.col-sm-5.col-md-5 > img").attr('src')
        const tertinggi = $("tr:nth-child(4) > td.text-center > button").attr('onclick');
        const tinggi = $("tr:nth-child(5) > td.text-center > button").attr('onclick');
        const biasa = $("tr:nth-child(6) > td.text-center > button").attr('onclick');
        const audio = $("tr:nth-child(2) > td.text-center > button").attr('onclick');
        let data = {
          hdr: tertinggi,
          hd: tinggi,
          sd: biasa,
          mp3: audio
        };

        let ambil = data.sd;
        if (type == "hdr") {
          ambil = data.hdr;
        } else if (type == "hd") {
          ambil = data.hd;
        } else if (type == "sd") {
          ambil = data.sd;
        } else if (type == "audio") {
          ambil = data.mp3;
        } else if (type == "cek") {
          return resolve(data)
        }


// Menggunakan regex untuk mengekstrak informasi yang diperlukan
let extractedData = ambil.match(/'(.*?)','(.*?)','(.*?)','(.*?)',.*?'(.*?)','(.*?)'/);

// Membuat objek hasil dari data yang diekstrak
let hasil = {
    platform: "youtube",
    url: extractedData[1],
    title: extractedData[2],
    id: extractedData[3],
    ext: extractedData[4],
    note: extractedData[5],
    format: extractedData[6]
};

let inibang = await axios.post(`https:`+`//yt`+`1ss.pro/`+`mat`+`es/en/`+`convert?id=${hasil.id}`,
hasil, {
headers: {
"accept": "application/json, text/javascript, */*; q=0.01",
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "cookie": "sc_is_visitor_unique=rx12884893.1698641321.F644C5CB57ED4F178299746B4596E8F1.2.2.1.1.1.1.1.1.1",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
}
})

const download = {
url: hasil.url,
title: hasil.title,
download: inibang.data.downloadUrlX,
thumb: thum
}
        console.log(download)
        resolve(download);
      }
    } catch (error) {
      console.error("Terjadi kesalahan:", error);
      reject(error);
    }
  });
}

// Panggil fungsi ytdl
//ytdl("https://youtu.be/t9VWICGOD90?si=H9xO3z4IRiU7Hif6", "audio")


export { ytdl }



