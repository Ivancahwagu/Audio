import serialize, { getContentType } from "./lib/mess.js";
import Color from "./lib/color.js";
import fetch from "node-fetch";
import fs from "fs"
import { reSize  } from "./lib/resize.js"
import { igdl3 } from "./scrape/igdlv3.js"
import { tesmime } from "./lib/checkmime.js"
import { ttdl } from "./scrape/ttdlv2.js"
import { ytshort } from "./scrape/ytshort.js"
import { ytdl } from "./scrape/ytdl.js"
import {logo} from "./scrape/logo.js"
import {ai} from "./scrape/ai.js"

import {
     toAudio,
     toPTT,
     toVideo,
     ffmpeg,
   } from "./lib/convert.js"

export default async function message(van, store, m) {
   try {
      global.user = "@" + m.sender.split("@")[0]
      let quoted = m.isQuoted ? m.quoted : m
      let isCommand = m.prefix && m.body.startsWith(m.prefix) || false
       global.quo  = {quoted: m, ephemeralExpiration: m.expiration};
      // mengabaikan pesan dari bot
      if (m.isBot) return
      if (m.from.endsWith("net") || m.from === "120363025908944080@g.us") {
      if (!(m.sender.startsWith("62") || m.sender.startsWith("60"))) {
         await m.reply("*Maaf bot ini khusus untuk nomor indonesia*")
         if (m.from.endsWith("us")){
            
         }
         return await van.updateBlockStatus(m.sender, "block")
      }
      }
      if (m.from.endsWith("@g.us")){
         if (!m.from === "120363025908944080@g.us") return 
      }
      // memunculkan ke log
      if (m.message && !m.isBot) {
          console.log(Color.black(Color.bgWhite("FROM")), Color.black(Color.bgGreen(m.pushName)), Color.black(Color.yellow(m.sender)) + "\n" + Color.black(Color.bgWhite("IN")), Color.black(Color.bgGreen(m.isGroup ? "Group" : "Private")) + "\n" + Color.black(Color.bgWhite("MESSAGE")), Color.black(Color.bgGreen(m.body || m.type)) + "\n", m.from)
         //console.log(m)
      }
      // command
      switch (isCommand ? m.command.toLowerCase() : false) {
            case "menu": case "info": case "m": {
               let text = { 
                  main: [
                  "menu",
                  "help",
                  "donasi"
               ],
                  download: [
                     "ig",
                     "iga",
                     "tt",
                     "tiktok",
                     "tta",
                     "tiktokaudio",
                     "yt",
                     "youtube"
                  ]
               }
               let img = await fs.readFileSync("./img/menu2.jpg")
               await van.sendMessage(m.from, {
document: {url: "https://github.com"},
jpegThumbnail: await reSize(img, 300, 150),
fileName: "menu sansbot",
mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
fileLength: "99999999999999",
pageCount: "999999",
caption: `hai ${user},
total fitur: ${text.main.length + text.download.length}

berikut list menunya:
               
[ main ]

${text.main.map(i => m.prefix + i).join("\n")}

[ downloader ]

${text.download.map(i => m.prefix + i).join("\n")}

ini bot baru!
jadi bot ini masih masa pengembangan`, contextInfo: {
mentionedJid: [m.sender],
       isForwarded: true,
       forwardedNewsletterMessageInfo: {
         newsletterJid: '120363144038483540@newsletter',
         newsletterName: 'sans bot by ivan',
         accessibilityText: 'sans bot by ivan',
            contentType: 2,
       },
       businessMessageForwardInfo: {
         businessOwnerJid: '62858090113574@s.whatsapp.net'
   },
externalAdReply: {
thumbnail: await fs.readFileSync("./img/menu.jpg"),
title: "sansbot-lite",
body: "menu",
sourceUrl: "https://wa.me/6285809011357",
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {quoted: m, ephemeralExpiration: m.expiration})
            }
               break
         case "donasi": {
            await van.sendMessage(m.from, { image: { url: "https://telegra.ph/file/5bd38afcc2d78f05dbfe3.jpg" },
                                           fileName: "donasi.jpg",
caption: `hai kak ${user}, scan kode qr qris ini untuk mensupport bot ini`, contextInfo: {
   mentionedJid: [ m.sender ]
}
}, { quoted: m, ephemeralExpiration: m.expiration})
         }
            break
         case "owner": {
            const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:ivan\n' // full name
            + 'ORG:owner sansbot;\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=6285809011357:+62 858-0901-1357\n' // WhatsApp ID + phone number
            + 'END:VCARD'
            await van.sendMessage(
                   m.from,
                   { 
                       contacts: { 
                           displayName: 'ivan', 
                           contacts: [{ vcard }] 
                       }
                   },{ quoted: m , ephemeralExpiration: m.expiration}
               )

         }
            break
            case "send": {
               if (!m.text) return m.reply("link?")
               await van.sendMedia(m.from, m.text, quo)
            }
            break
         case "ig": case "instagram": {
            if (!m.text) return m.reply("link?")
            let hasil = await igdl3(m.text)
            for (let i = 0; i < hasil.length; i++) {
               await van.sendMedia(m.from, hasil[i], quo)
            }
         }
            break
         case "iga": case "igaudio": case "instagramaudio":{
            if (!m.text) return m.reply("mana linknya?")
            let hasil = await igdl3(m.text)
            hasil = await (await fetch(hasil[0])).buffer()
            await van.sendAudio(m.from, hasil, quo)
            }
               break
      }//end
    } catch (e) {
        console.log("terjadi kesalahan: " + e)
    }
}